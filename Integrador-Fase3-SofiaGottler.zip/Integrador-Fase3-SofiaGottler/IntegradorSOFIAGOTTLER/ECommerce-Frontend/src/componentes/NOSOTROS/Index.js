import { useEffect } from 'react'
import './Index.css'

export function Index(props) {
    const { titulo: enunciado } = props // destructuring Object con alias

    useEffect(() => {
        console.log('Componente Index Nosotros (montado)')

        return () => {
            console.log('Componente Index Nosotros (desmontado)')
        }
    }, [])

    return (
        <div className="Nosotros">
            <div className="jumbotron">
                <h3>{enunciado}</h3>
                <hr />
                <p>
                    ¡Bienvenido a FUTKITS, tu destino definitivo para la auténtica pasión futbolera y moda retro! En FUTKITS, fusionamos el legado del fútbol con las últimas tendencias para ofrecerte una selección única de camisetas que celebra la rica historia del deporte rey.
                    En nuestro apasionante espacio virtual, nos enorgullece presentar una cuidadosa curaduría de camisetas de fútbol, tanto retro como actuales, diseñadas para satisfacer los gustos más exigentes de nuestra comunidad. En FUTKITS, entendemos que cada camiseta cuenta una historia, y nos esforzamos por ofrecer no solo prendas de alta calidad, sino también una experiencia de compra que refleje nuestra dedicación al fútbol y al estilo.
                    Lo que nos distingue en FUTKITS va más allá de las telas y los diseños; es nuestra pasión compartida por el deporte y la moda. Nuestro equipo está formado por entusiastas del fútbol que comparten el deseo de revivir momentos históricos a través de camisetas retro auténticas y de apoyar a los equipos actuales con las equipaciones más modernas.
                    En FUTKITS, no solo vendemos camisetas; creamos conexiones, celebramos victorias y cultivamos un sentido de comunidad que une a los aficionados alrededor del mundo. Explora nuestro catálogo, sumérgete en la emoción de cada camiseta y únete a la familia FUTKITS, donde el fútbol y la moda se encuentran en armonía.
                    Gracias por elegir FUTKITS como tu destino para las mejores camisetas de fútbol. Juntos, vestimos la pasión, la historia y el estilo en cada jersey que ofrecemos. ¡Bienvenido a la experiencia FUTKITS, donde el fútbol se vive con cada hilo!
                </p>
            </div>
        </div>
    )
}
