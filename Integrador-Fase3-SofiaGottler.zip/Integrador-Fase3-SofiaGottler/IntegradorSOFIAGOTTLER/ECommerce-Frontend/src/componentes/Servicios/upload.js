const URL_API_UPLOAD = 'http://localhost:8080/api/upload/'

export function enviarFormDataAjax(data, progress, urlfoto) {
    let porcentaje = 0

    const xhr = new XMLHttpRequest()
    xhr.open('post', URL_API_UPLOAD)

    xhr.addEventListener('load', () => {
        if(xhr.status === 200) {
            const rta = JSON.parse(xhr.response)
            //console.log(rta)

            const url = rta.urlFotoFTP
            if(urlfoto) urlfoto(url)
        }
    })

    xhr.upload.addEventListener('progress', e => {
        if(e.lengthComputable) {
            porcentaje = parseInt((e.loaded * 100) / e.total)
            //console.warn(porcentaje + '%')
            if(progress) progress(porcentaje)
        }
    })

    xhr.send(data)
}