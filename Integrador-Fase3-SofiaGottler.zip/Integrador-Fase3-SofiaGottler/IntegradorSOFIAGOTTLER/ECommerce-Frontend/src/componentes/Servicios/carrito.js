import axios from "axios"

//const URL_API_CARRITO = 'https://5c8ef17a3e557700145e85c7.mockapi.io/carrito/'
const URL_API_CARRITO = 'http://localhost:8080/api/carrito/'


export async function enviarCarrito(carrito) {
    try {
        const { data:carritoGuardado } = await axios.post(URL_API_CARRITO, {pedido: carrito})
        return carritoGuardado
    }
    catch(error) {
        console.error('ERROR POST AXIOS:', error.message)
        return {}
    }
}


