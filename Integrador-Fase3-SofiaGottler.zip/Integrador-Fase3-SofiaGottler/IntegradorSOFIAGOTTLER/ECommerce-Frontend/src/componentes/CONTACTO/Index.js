import React, { useState, useEffect } from 'react';
import './Index.css';

export function Index(props) {
    const { titulo: enunciado } = props;
    const [formularioEnviado, setFormularioEnviado] = useState(false);

    useEffect(() => {
        console.log('Componente Index Contacto (montado)');

        return () => {
            console.log('Componente Index Contacto (desmontado)');
        };
    }, []);

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log('Formulario enviado');
        setFormularioEnviado(true);
    };

    return (
        <div className="Contacto">
            <div className="jumbotron">
                <h3>{enunciado}</h3>
                <hr />
                <p>
                    ¿Tienes preguntas, comentarios o simplemente quieres compartir tu entusiasmo por el fútbol? ¡Estamos aquí para escucharte! No dudes en enviarnos un correo electrónico a contacto@futkits.com. También puedes seguirnos en nuestras redes sociales para estar al tanto de las últimas novedades y ofertas especiales. En FUTKITS, valoramos la conexión con nuestra comunidad de apasionados por el fútbol. ¡Esperamos saber de ti pronto!
                </p>

                {formularioEnviado ? (
                    <div className="mensaje-exito">
                        ¡Formulario enviado con éxito!
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} className="contacto-form">
                        <div className="input-group">
                            <label htmlFor="nombre">Nombre:</label>
                            <input type="text" name="nombre" id="nombre" required />
                            <div className="error-detail"></div>
                        </div>
                        <div className="input-group">
                            <label htmlFor="email">E-mail:</label>
                            <input type="email" name="email" id="email" required />
                            <div className="error-detail"></div>
                        </div>
                        <div className="input-group">
                            <label htmlFor="comentarios">Comentarios:</label>
                            <textarea id="comentarios" name="comentarios" rows="4" required></textarea>
                            <div className="error-detail"></div>
                        </div>
                        <input type="submit" value="Enviar" />
                    </form>
                )}
            </div>
        </div>
    );
}
