export const RutaNoValida = () => 
    <div className="RutaNoValida">
        <div className="alert alert-danger">
            <h3>Error 404: Ruta no válida</h3>
        </div>
    </div>