import './Navbar.css'

import { NavLink } from "react-router-dom";


export const Navbar = () =>
    <nav className="navbar navbar-expand-md navbar-dark bg-dark separador-navbar">
        <NavLink className="navbar-brand" to="/">Home</NavLink>
        
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
                <li className="nav-item">
                    <NavLink className="nav-link" to="/inicio">Inicio</NavLink>
                </li>
                <li className="nav-item">
                    <NavLink className="nav-link" to="/alta">Alta</NavLink>
                </li>
                <li className="nav-item">
                    <NavLink className="nav-link" to="/carrito">Carrito</NavLink>
                </li>
                <li className="nav-item">
                    <NavLink className="nav-link" to="/contacto">Contacto</NavLink>
                </li>
                <li className="nav-item">
                    <NavLink className="nav-link" to="/nosotros">Nosotros</NavLink>
                </li>
                
            </ul>
        </div>
    </nav>
