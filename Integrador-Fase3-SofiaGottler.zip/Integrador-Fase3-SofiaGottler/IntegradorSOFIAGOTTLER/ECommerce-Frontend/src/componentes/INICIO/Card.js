import './Card.css'

export const Card = props => {

    const { producto, agregarCarritoID } = props

    return (
        <div className="Card">
            <section>
                <h3>{producto.nombre}</h3>
                <img src={producto.foto} alt="" />
                <p><b className="precio">Precio: </b>${producto.precio}</p>
                <p><b>Stock: </b>{producto.stock}</p>
                <p><b>Marca: </b>{producto.marca}</p>
                <p><b>Categoría: </b>{producto.categoria}</p>
                <p><b>Detalles: </b>{producto.detalles}</p>
                <br />
                <p><b style={{color:'darkgreen'}}>Envío: </b>{producto.envio? 'Si' : 'No'}</p>
                <br />
                <button onClick={
                    () => agregarCarritoID(producto.id)
                }>Agregar al carrito</button>
                <br />
            </section>
        </div>
    )
}